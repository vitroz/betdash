<?php

header('Location: cliente/dashboard.html');